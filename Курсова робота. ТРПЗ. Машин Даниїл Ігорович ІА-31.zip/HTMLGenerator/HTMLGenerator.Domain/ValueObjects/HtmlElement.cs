﻿namespace HTMLGenerator.Domain.ValueObjects
{
    public class HtmlElement
    {
        public string Value { get; set; }
    }
}
